<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col fs-13 text-muted text-center">
                &copy;
                <script>document.write(new Date().getFullYear())</script> - Made with <span
                    class="mdi mdi-heart text-danger"></span> by
                <a href="https://github.com/dkpankaj1" target="_blank" class="text-reset fw-semibold">dkpankaj1</a>
            </div>
        </div>
    </div>
</footer>