<?php

return [
    App\Providers\AppServiceProvider::class,
    Dkpankaj1\AdminKit\AdminKitServiceProvider::class,
    Dkpankaj1\Toastr\ToastrServiceProvider::class,
];
