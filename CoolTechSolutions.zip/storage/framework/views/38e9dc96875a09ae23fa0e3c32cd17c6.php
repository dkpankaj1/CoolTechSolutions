<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Complains List</h4>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Mobile</th>
                            <th scope="col">Service</th>
                            <th scope="col">Status</th>
                            <th scope="col">Created At</th>
                            <th scope="col">Updated At</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $complains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $complain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($complain->id); ?></td>
                                <td><?php echo e($complain->name); ?></td>
                                <td><?php echo e($complain->number); ?></td>
                                <td><?php echo e($complain->service); ?></td>

                                <td>
                                    <span
                                        class="badge <?php echo e($complain->status === 'pending' ? 'text-bg-warning' : ($complain->status === 'in-progress' ? 'text-bg-info' : 'text-bg-success')); ?>">
                                        <?php echo e(ucfirst($complain->status)); ?>

                                    </span>
                                </td>

                                <td><?php echo e($complain->created_at->diffForHumans()); ?></td>
                                <td><?php echo e($complain->updated_at->diffForHumans()); ?></td>
                                <td>
                                    <div class="d-flex gap-1">

                                        <a class="btn btn-success btn-sm"
                                            href="<?php echo e(route('admin.complains.edit', $complain)); ?>">Edit</a>

                                        <a class="btn btn-info btn-sm"
                                            href="<?php echo e(route('admin.complains.show', $complain)); ?>">Show</a>

                                        <form action="<?php echo e(route('admin.complains.destroy', $complain->id)); ?>"
                                            method="POST" onsubmit="return confirm('Are you sure?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                        </form>
                                    </div>
                                </td>

                            </tr>                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center">No Complains Found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="9">
                                <div class="d-flex justify-content-center">
                                    <?php echo e($complains->links()); ?>

                                </div>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\php-project\CoolTechSolutions\resources\views/admin/complains/index.blade.php ENDPATH**/ ?>