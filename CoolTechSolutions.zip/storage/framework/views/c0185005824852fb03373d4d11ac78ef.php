<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container py-5">
        <h1 class="fw-bold mb-5 text-dark">Complaint Details</h1>

        <!-- Complaint Details Table -->
        <div class="card shadow-sm">
            <div class="card-body">
                <h1 class="card-title fw-semibold mb-4">Complaint #<?php echo e($complain->id); ?></h1>
                <div class="table-responsive">
                    <table class="table table-bordered table-sm">
                        <tbody>
                            <tr>
                                <th scope="row" class="w-25">ID</th>
                                <td><?php echo e($complain->id); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Name</th>
                                <td><?php echo e($complain->name); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Mobile</th>
                                <td><?php echo e($complain->number); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Email</th>
                                <td><?php echo e($complain->email); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Service</th>
                                <td><?php echo e($complain->service); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Address</th>
                                <td><?php echo e($complain->address); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Description</th>
                                <td><?php echo e($complain->description); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Status</th>
                                <td>
                                    <span class="badge <?php echo e($complain->status === 'pending' ? 'text-bg-warning' : ($complain->status === 'in-progress' ? 'text-bg-info' : 'text-bg-success')); ?>">
                                        <?php echo e(ucfirst($complain->status)); ?>

                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Created At</th>
                                <td><?php echo e($complain->created_at->format('d M Y, H:i')); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Updated At</th>
                                <td><?php echo e($complain->updated_at->format('d M Y, H:i')); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="text-center mt-5">
            <a href="<?php echo e(route('admin.complains.edit', $complain)); ?>" class="btn btn-success px-4 py-2 me-2">Edit</a>
            <button onclick="window.print()" class="btn btn-primary px-4 py-2">Print</button>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH E:\php-project\CoolTechSolutions\resources\views/admin/complains/show.blade.php ENDPATH**/ ?>