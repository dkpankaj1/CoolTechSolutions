<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8" />
    <title>Dashboard | AdminKit</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc." />
    <meta name="author" content="Zoyothemes" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/kadso/images/favicon.ico')); ?>">

    <!-- App css -->
    <link href="<?php echo e(asset('assets/kadso/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="app-style" />

    <!-- Icons -->
    <link href="<?php echo e(asset('assets/kadso/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/toastr/toastr.min.css')); ?>" />

</head>

<!-- body start -->

<body data-menu-color="dark" data-sidebar="default">

    <!-- Begin page -->
    <div id="app-layout">


        <!-- Topbar Start -->
        <?php echo $__env->make('admin.layouts._app.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- end Topbar -->

        <!-- Left Sidebar Start -->
        <?php echo $__env->make('admin.layouts._app.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- Left Sidebar End -->

        <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->

        <div class="content-page">
            <div class="content">

                <!-- Start Content-->
                <div class="container-fluid">

                    <div class="py-3 d-flex align-items-sm-center flex-sm-row flex-column">
                        <div class="flex-grow-1">
                            <h4 class="fs-18 fw-semibold m-0">Dashboard</h4>
                        </div>

                        <div class="text-end">
                            
                        </div>
                    </div>


                    <?php echo e($slot); ?>



                </div> <!-- container-fluid -->

            </div> <!-- content -->

            <!-- Footer Start -->
            <?php echo $__env->make('admin.layouts._app.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <!-- end Footer -->

        </div>
        <!-- ============================================================== -->
        <!-- End Page content -->
        <!-- ============================================================== -->


    </div>
    <!-- end page -->

    <!-- Vendor -->
    <script src="<?php echo e(asset('assets/kadso/libs/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/kadso/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/kadso/libs/simplebar/simplebar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/kadso/libs/node-waves/waves.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/kadso/libs/waypoints/lib/jquery.waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/kadso/libs/jquery.counterup/jquery.counterup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/kadso/libs/feather-icons/feather.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/toastr/toastr.min.js')); ?>"></script>
    <?php if (isset($component)) { $__componentOriginalfcaf2bb158d4cf0e76d0a025b53b596a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfcaf2bb158d4cf0e76d0a025b53b596a = $attributes; } ?>
<?php $component = Dkpankaj1\Toastr\View\Components\Toaster::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('toastr'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Dkpankaj1\Toastr\View\Components\Toaster::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfcaf2bb158d4cf0e76d0a025b53b596a)): ?>
<?php $attributes = $__attributesOriginalfcaf2bb158d4cf0e76d0a025b53b596a; ?>
<?php unset($__attributesOriginalfcaf2bb158d4cf0e76d0a025b53b596a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfcaf2bb158d4cf0e76d0a025b53b596a)): ?>
<?php $component = $__componentOriginalfcaf2bb158d4cf0e76d0a025b53b596a; ?>
<?php unset($__componentOriginalfcaf2bb158d4cf0e76d0a025b53b596a); ?>
<?php endif; ?>

    <!-- App js-->
    <script src="<?php echo e(asset('assets/kadso/js/app.js')); ?>"></script>

</body>

</html><?php /**PATH E:\php-project\CoolTechSolutions\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>