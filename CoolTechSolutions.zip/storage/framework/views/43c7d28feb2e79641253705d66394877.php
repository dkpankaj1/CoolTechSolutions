
<?php if (isset($component)) { $__componentOriginaleace9cbc035c4368375a3a737ed40872 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleace9cbc035c4368375a3a737ed40872 = $attributes; } ?>
<?php $component = App\View\Components\WebLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('web-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\WebLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<!--===========================
        Start Breadcrumb
===========================-->
<section class="breadcrumb_section text-center section_padding" style="background-image:url('<?php echo e(asset('assets/images/slider-3.webp')); ?>')">
    <ul class="breadcrumb">
        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
        <li> About</li>
    </ul>
    <h1>About us</h1>
</section><!--end .breadcrumb_section-->



<!--===========================
        Start About Service
===========================-->
<section class="about_service_area section_padding">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="about_service_left">
                    <p class="about_service_year text-center">
                        20
                        <span>years
                        experience</span>
                    </p><!--end .about_service_discount-->
                </div><!--end .about_service_right_left-->
            </div><!--end .col-md-6end .col-md-6-->
            <div class="col-md-6">
                <div class="about_service_right">
                    <div class="hero-title-with-shape text-justify">
                        <h4 class="heading_with_border">About Us</h4>
                        <h1>We are trusted source of ac and heating maintenance repairs company</h1>
                        <p>We are a trusted source of ac and heating maintenance repairs company. We have been in the business for over 20 years and have a proven track record of providing quality service to our customers.</p>
                    </div>
                    <ul>
                        <li><i class="fa fa-check-circle"></i> Unmatched performance, satisfaction service guarantees</li>
                        <li><i class="fa fa-check-circle"></i> Home protection through our shoe covers and mats</li>
                        <li><i class="fa fa-check-circle"></i> Upfront, flat rate pricing—no overtime charges</li>
                        <li><i class="fa fa-check-circle"></i> 24 / 7 availability for all emergency services</li>
                        <li><i class="fa fa-check-circle"></i> Fixed right promise—done right or it’s free</li>
                        <li><i class="fa fa-check-circle"></i> Clear communication and updates on service arrival</li>
                    </ul>
                    
                </div><!--end .about_service_right-->
            </div><!--end .col-md-6-->
        </div><!--end .row-->
    </div><!--end .container-->
</section><!--end .about_service_area-->
<!--===========================
        End About Service
===========================-->

<!--===========================
        Start Testimonial
===========================-->
<section class="testimonial_area text-center section_padding">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="testimonial_slider owl-carousel">
                    <div class="testimonial_details">
                        <p>This is due to their excellent service, competitive pricing and customer support . It's throughly refresing to get such a personal touch.</p>
                        <h4>Mark Doe</h4>
                        <span>Director</span>
                    </div><!--end .testimonial_details-->
                    <div class="testimonial_details">
                        <p>This is due to their excellent service, competitive pricing and customer support . It's throughly refresing to get such a personal touch.</p>
                        <h4>Jim Doe</h4>
                        <span>Developer</span>
                    </div><!--end .testimonial_details-->
                    <div class="testimonial_details">
                        <p>This is due to their excellent service, competitive pricing and customer support . It's throughly refresing to get such a personal touch.</p>
                        <h4>Shirley Smith</h4>
                        <span>Director</span>
                    </div><!--end .testimonial_details-->
                </div><!--end .testimonial_slider-->
            </div><!--end .col-md-8-->
        </div><!--end .row-->
    </div><!--end .container-->
    <h1 class="testimonial_heading_shape">Testimonials</h1>
</section>
<!--===========================
        End Testimonial
===========================-->

<!--===========================
        Start Team Member
===========================-->
<section class="team_member_area section_padding section_border text-center">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="hero-section-title text-center">
                    <h1>Meet The Team</h1>
                </div><!--end .hero-section-title-->
            </div><!--end .col-md-12-->

            <div class="col-md-3 col-sm-6">
                <div class="team_member">
                    <img src="assets/images/team/team-1.jpg" alt="team 1">
                    <div class="team_details">
                        <h3>Rose Ford <span class="skills">- Manager</span></h3>
                        <ul class="team_socials">
                            <li><a href=""><i class="fa fa-twitter"></i></a></li>
                            <li><a href=""><i class="fa fa-facebook"></i></a></li>
                            <li><a href=""><i class="fa fa-youtube-play"></i></a></li>
                        </ul>
                    </div><!--end .team_details-->
                </div><!--end .team_member-->
            </div><!--end .col-md-3-->
            <div class="col-md-3 col-sm-6">
                <div class="team_member">
                    <img src="assets/images/team/team-2.jpg" alt="team 2">
                    <div class="team_details">
                        <h3>Mike Olsen <span class="skills">- Worker</span></h3>
                        <ul class="team_socials">
                            <li><a href=""><i class="fa fa-twitter"></i></a></li>
                            <li><a href=""><i class="fa fa-facebook"></i></a></li>
                            <li><a href=""><i class="fa fa-youtube-play"></i></a></li>
                        </ul>
                    </div><!--end .team_details-->
                </div><!--end .team_member-->
            </div><!--end .col-md-3-->
            <div class="col-md-3 col-sm-6">
                <div class="team_member">
                    <img src="assets/images/team/team-3.jpg" alt="team 3">
                    <div class="team_details">
                        <h3>Emmyson <span class="skills">- Founder</span></h3>
                        <ul class="team_socials">
                            <li><a href=""><i class="fa fa-twitter"></i></a></li>
                            <li><a href=""><i class="fa fa-facebook"></i></a></li>
                            <li><a href=""><i class="fa fa-youtube-play"></i></a></li>
                        </ul>
                    </div><!--end .team_details-->
                </div><!--end .team_member-->
            </div><!--end .col-md-3-->
            <div class="col-md-3 col-sm-6">
                <div class="team_member">
                    <img src="assets/images/team/team-4.jpg" alt="team 4">
                    <div class="team_details">
                        <h3>John Smith <span class="skills">- Worker</span></h3>
                        <ul class="team_socials">
                            <li><a href=""><i class="fa fa-twitter"></i></a></li>
                            <li><a href=""><i class="fa fa-facebook"></i></a></li>
                            <li><a href=""><i class="fa fa-youtube-play"></i></a></li>
                        </ul>
                    </div><!--end .team_details-->
                </div><!--end .team_member-->
            </div><!--end .col-md-3-->
        </div><!--end .row-->
    </div><!--end .container-->
</section>
<!--===========================
        End Team Member
===========================-->


<div class="clients_logo_area text-center section_padding">
    <div class="container">
        <div class="row">
            <div class="clients_logo owl-carousel">
                <div class="item">
                    <img src="assets/images/brand1.png" alt="Clients Logos">
                </div><!--end .item-->
                <div class="item">
                    <img src="assets/images/brand2.png" alt="Clients Logos">
                </div><!--end .item-->
                <div class="item">
                    <img src="assets/images/brand3.png" alt="Clients Logos">
                </div><!--end .item-->
                <div class="item">
                    <img src="assets/images/brand4.png" alt="Clients Logos">
                </div><!--end .item-->
                <div class="item">
                    <img src="assets/images/brand5.png" alt="Clients Logos">
                </div><!--end .item-->
                <div class="item">
                    <img src="assets/images/brand6.png" alt="Clients Logos">
                </div><!--end .item-->
                <div class="item">
                    <img src="assets/images/brand7.png" alt="Clients Logos">
                </div><!--end .item-->

            </div><!--end .clients_logo-->
        </div><!--end .row-->
    </div><!--end .container-->
</div>


    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleace9cbc035c4368375a3a737ed40872)): ?>
<?php $attributes = $__attributesOriginaleace9cbc035c4368375a3a737ed40872; ?>
<?php unset($__attributesOriginaleace9cbc035c4368375a3a737ed40872); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleace9cbc035c4368375a3a737ed40872)): ?>
<?php $component = $__componentOriginaleace9cbc035c4368375a3a737ed40872; ?>
<?php unset($__componentOriginaleace9cbc035c4368375a3a737ed40872); ?>
<?php endif; ?>


<?php /**PATH E:\php-project\CoolTechSolutions\resources\views/website/pages/about.blade.php ENDPATH**/ ?>