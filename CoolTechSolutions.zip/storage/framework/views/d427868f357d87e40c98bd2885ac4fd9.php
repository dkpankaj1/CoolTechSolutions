<div class="app-sidebar-menu">
    <div class="h-100" data-simplebar>

        <!--- Sidemenu -->
        <div id="sidebar-menu">

            <div class="logo-box">
                <a href="index.html" class="logo logo-light">
                    <span class="logo-sm">
                        <img src="<?php echo e(asset('assets/kadso/images/logo-sm.png')); ?>" alt="" height="22">
                    </span>
                    <span class="logo-lg">
                        <img src="<?php echo e(asset('assets/kadso/images/logo-light.png')); ?>" alt="" height="24">
                    </span>
                </a>
                <a href="index.html" class="logo logo-dark">
                    <span class="logo-sm">
                        <img src="<?php echo e(asset('assets/kadso/images/logo-sm.png')); ?>" alt="" height="22">
                    </span>
                    <span class="logo-lg">
                        <img src="<?php echo e(asset('assets/kadso/images/logo-dark.png')); ?>" alt="" height="24">
                    </span>
                </a>
            </div>

            <ul id="side-menu">

                <li class="menu-title">Menu</li>

                <li>
                    <a href="<?php echo e(route('admin.dashboard')); ?>">
                        <i data-feather="home"></i>
                        <span> Dashboard </span>
                    </a>
                </li>

                <li class="menu-title">Pages</li>

                <li>
                    <a href="#sidebarAuth" data-bs-toggle="collapse">
                        <i data-feather="grid"></i>
                        <span> Complains </span>
                        <span class="menu-arrow"></span>
                    </a>
                    <div class="collapse" id="sidebarAuth">
                        <ul class="nav-second-level">
                          <li>
                                <a href="<?php echo e(route('admin.complains.create')); ?>">New Complain</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('admin.complains.index')); ?>">All complain</a>
                            </li>
                          
                        </ul>
                    </div>
                </li>

                
                

                <li class="menu-title">Accounts</li>

                <li>
                    <a href="#sidebarMyAccount" data-bs-toggle="collapse">
                        <i data-feather="user"></i>
                        <span> Account </span>
                        <span class="menu-arrow"></span>
                    </a>
                    <div class="collapse" id="sidebarMyAccount">
                        <ul class="nav-second-level">
                            <li>
                                <a href="<?php echo e(route('admin.account.index')); ?>">My Account</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('admin.account.update')); ?>">Update Profile</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('admin.account.password')); ?>">Change Password</a>
                            </li>
                        </ul>
                    </div>
                </li>

            </ul>

        </div>
        <!-- End Sidebar -->

        <div class="clearfix"></div>

    </div>
</div><?php /**PATH E:\php-project\CoolTechSolutions\resources\views/admin/layouts/_app/sidebar.blade.php ENDPATH**/ ?>