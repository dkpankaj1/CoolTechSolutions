<!DOCTYPE html>
<html lang="en">
    
        <head>
            <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Loazzne - Heating & Air Conditioning Repair & Installation Services HTML Template</title>
    <!--Google font-->
    <link href="https://fonts.googleapis.com/css?family=Josefin+Sans:100,300,400,600,600i,700" rel="stylesheet">
    <!--favicon-->
    <link rel="icon" href="assets/images/favicon.png">
    <!--stylesheet-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/fontello.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>">
        </head>

        <body>
            <?php echo $__env->make('website.layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo e($slot); ?>


            <?php echo $__env->make('website.layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>



            <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
            <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
            <script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
            <script src="<?php echo e(asset('assets/js/jquery.magnific-popup.min.js')); ?>"></script>
            <script src="<?php echo e(asset('assets/js/waypoint.js')); ?>"></script>
            <script src="<?php echo e(asset('assets/js/jquery.counterup.min.js')); ?>"></script>
            <script src="<?php echo e(asset('assets/js/custom-map.js')); ?>"></script>
            <script src="<?php echo e(asset('https://maps.googleapis.com/maps/api/js?key=AIzaSyA_Agsvf36du-7l_mp8iu1a-rXoKcWfs2I')); ?>"></script>
            <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
        </body>
    

</html>
<?php /**PATH E:\php-project\CoolTechSolutions\resources\views/website/layouts/app.blade.php ENDPATH**/ ?>